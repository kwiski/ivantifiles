﻿try {
  . ".\common.ps1"
}
catch {
  Write-Output "Error while loading common.ps1, please ensure it's in the same directory as this script"
  exit 
}
Write-Host -ForegroundColor Gray "This script should be run as Administrator, it will remove the ELK stack services on your machine."

Write-Host -ForegroundColor Yellow "Stopping services..."
Invoke-Expression -command "$nssm_folder\win64\nssm stop Kibana"
Invoke-Expression -command "$nssm_folder\win64\nssm stop Logstash"
Invoke-Expression -command "$nssm_folder\win64\nssm stop elasticsearch-service-x64"

Write-Host -ForegroundColor Yellow "Removing services..."
Invoke-Expression -command "$elasticsearch_folder\bin\elasticsearch-service remove"
Invoke-Expression -command "$nssm_folder\win64\nssm.exe remove Logstash confirm"
Invoke-Expression -command "$nssm_folder\win64\nssm.exe remove Kibana confirm"

Write-Host -ForegroundColor Yellow "Removing scheduled task..."
Unregister-ScheduledTask -TaskName $curator_job -Confirm:$false

if($env:JAVA_HOME -eq $jdk_folder)
{
  Write-Host -ForegroundColor Yellow "Removing JAVA_HOME as it was using the in-built elastic JDK"
  [System.Environment]::SetEnvironmentVariable("JAVA_HOME", $null, "Machine")
}

Write-Host ""
Write-Host -ForegroundColor Green "The relevant services for the ELK stack have now been stopped. You may now delete $basefolder and it's contents to complete removal."