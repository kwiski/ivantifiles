﻿#Download Packages for ELK Stack
#Version: 20190712.1

# Use TLS1.2 for downloads
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

try {
    . ".\common.ps1"
}
catch {
    Write-Output "Error while loading common.ps1, please ensure it's in the same directory as this script"
    exit 
}

Write-Host -ForegroundColor Gray "This script will download the relevant ELK stack files and extract them on your machine."

# Setup base folder which we will use to run the ELK stack from
if (-not (Test-Path $basefolder) ) {
    Write-Host -ForegroundColor Yellow "Creating $basefolder as it did not exist.. "
    mkdir $basefolder
}
Write-Host -ForegroundColor Gray "Base folder for ELK stack is $basefolder"


$downloadfolder = Join-Path $basefolder "downloads"
if (-not (Test-Path $downloadfolder) ) {
    Write-Host -ForegroundColor Yellow "Creating $downloadfolder as it did not exist.. "
    mkdir $downloadfolder
}
Write-Host -ForegroundColor Gray "Downloads will be kept in $downloadfolder"
Write-Host ""

# Get each of the components we need 
foreach ($component in $components.GetEnumerator())
{
  $item = $component.Value

  $file_path = Join-Path -Path $downloadfolder -ChildPath $item.filename
  if (Test-Path $file_path)
  {
    Write-Host -ForegroundColor Green "Skipping download of $($component.Key) as $file_path already exists."
    continue
  }

  $progressPreference = 'silentlyContinue'
  Write-Host -ForegroundColor Yellow "Downloading $($component.key) from $($item.download_url)..."
  Invoke-WebRequest -Uri $item.download_url -OutFile $file_path
  $progressPreference = 'Continue' 
}

Write-Host ""

# Extract all the downloads
foreach ($component in $components.GetEnumerator())
{
  $item = $component.Value

  $file_path = Join-Path -Path $downloadfolder -ChildPath $item.filename
  if (-Not (Test-Path $file_path))
  {
    Write-Host -ForegroundColor Magenta "Could not find $file_path to extract, did the download complete OK?"
    continue
  }

  $folder_path = Join-Path -Path $basefolder -ChildPath $item.foldername
  if (Test-Path $folder_path)
  {
    Write-Host -ForegroundColor Green "Skipping extraction of $($component.Key) as $folder_path already exists."
    continue
  }

  Write-Host -ForegroundColor Yellow "Extracting $file_path to $folder_path... (this might take a while)"
  Expand-Archive -LiteralPath $file_path -DestinationPath $basefolder
}

# Copy the configuration files to known location
Write-Host ""
Write-Host "Copying configuration files to $basefolder..."

# Logstash
Copy-Item -Path .\logstash.conf $basefolder -Force

# Curator 
Copy-Item -Path .\action.yml $basefolder -Force
Copy-Item -Path .\config.yml $basefolder -Force

# Completed the download & extraction
Write-Host ""
Write-Host -ForegroundColor Green "Download and extraction of files required is now complete. To complete the installation you must do the following:"
Write-Host ""
Write-Host -ForegroundColor Green "Run the elk_setup.ps1 script as an Administrator."
Read-Host -Prompt "Press Enter to exit"
