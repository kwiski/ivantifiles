﻿#Setup services for ELK and start
#Version: 20190712.1

try {
  . ".\common.ps1"
}
catch {
  Write-Output "Error while loading common.ps1, please ensure it's in the same directory as this script"
  exit 
}

Write-Host -ForegroundColor Gray "This script should be run as Administrator, it will setup the ELK stack services on your machine."
 
foreach ($component in $components.GetEnumerator())
{
  $item = $component.Value

  $folder_path = Join-Path -Path $basefolder -ChildPath $item.foldername
  if (-Not(Test-Path $folder_path))
  {
    Write-Host -ForegroundColor Red "Unable to locate $($component.Key) in $folder_path. Have you run download.ps1?"
    exit
  }
}

# Use JDK provided by Elastic Stack if we don't have one already
if(!$env:JAVA_HOME)
{
  Write-Host -ForegroundColor Magenta "JAVA_HOME is not set, using the one provided by Elastic in $jdk_path"
  [System.Environment]::SetEnvironmentVariable("JAVA_HOME", $jdk_path, "Machine")
}

Write-Host "Configuring and setting up services.. "

#elasticsearch
$Env:ES_START_TYPE = "auto"
$ENV:ES_TMPDIR="$elasticsearch_folder\tmp"
Write-Host -ForegroundColor Yellow "Installing the ElasticSearch service..."
mkdir "$elasticsearch_folder\tmp" -Force
Invoke-Expression -command "$elasticsearch_folder\bin\elasticsearch-service install"

#kibana
$res = Get-Content "$kibana_folder\config\kibana.yml" | Select-String "#ivanti"

if (-not $res) {
    Write-Host -ForegroundColor Yellow "Updating the Kibana configuration..."  
    Add-Content "$kibana_folder\config\kibana.yml" 'server.host: "0.0.0.0"'
    Add-Content "$kibana_folder\config\kibana.yml" 'elasticsearch.hosts: "http://localhost:9200"'
    Add-Content "$kibana_folder\config\kibana.yml" '#ivanti'
}

Write-Host -ForegroundColor Yellow "Installing Kibana as a service..."
Invoke-Expression -command "$nssm_folder\win64\nssm install Kibana $kibana_folder\bin\kibana.bat"
Invoke-Expression -command "$nssm_folder\win64\nssm set Kibana AppDirectory $kibana_folder"
Invoke-Expression -command "$nssm_folder\win64\nssm set Kibana DependOnService elasticsearch-service-x64"
Invoke-Expression -command "$nssm_folder\win64\nssm set Kibana AppStdout $kibana_folder\service.log"
Invoke-Expression -command "$nssm_folder\win64\nssm set Kibana AppStderr $kibana_folder\service.log"

#logstash
Write-Host -ForegroundColor Yellow "Installing Logstash as a service..."
Invoke-Expression -command "$nssm_folder\win64\nssm install Logstash $logstash_folder\bin\logstash.bat -f $basefolder\logstash.conf"
Invoke-Expression -command "$nssm_folder\win64\nssm set Logstash AppStdout $logstash_folder\service.log"
Invoke-Expression -command "$nssm_folder\win64\nssm set Logstash AppStderr $logstash_folder\service.log"
Invoke-Expression -command "$nssm_folder\win64\nssm set Logstash DependOnService elasticsearch-service-x64"

#start all
Write-Host -ForegroundColor Yellow "Starting services..."
Invoke-Expression -command "$elasticsearch_folder\bin\elasticsearch-service start"
Invoke-Expression -command "$nssm_folder\win64\nssm start Kibana"
Invoke-Expression -command "$nssm_folder\win64\nssm start Logstash"

# Setup scheduled task to run curator
Write-Host -ForegroundColor Yellow "Setting up a daily cleanup of ElasticSearch at 10pm..."
$action = New-ScheduledTaskAction -Execute "$curator_folder\curator.exe" -Argument "$basefolder\action.yml --config $basefolder\config.yml"
$trigger = New-ScheduledTaskTrigger -Daily -At 10pm
$principal = New-ScheduledTaskPrincipal -UserID "NT AUTHORITY\SYSTEM" -LogonType ServiceAccount
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName $curator_job -Description "Daily cleanup of Elastic Search database" -principal $principal

# Completed the setup
Write-Host ""
Write-Host -ForegroundColor Green "The relevant services for the ELK stack should have now been started. Review the output above to confirm."
Write-Host -ForegroundColor Green "You will now need to configure auditing for your File Director cluster to this servers IP address and port 10514."
Write-Host -ForegroundColor Green "Once this is complete, you can navigate to Kibana @ http://localhost:5601, setup index patterns and import the dashboards provided"