# Set properties for the various components we want to setup
# ElasticSearch (ES) used to store the audit data
$elasticsearch = @{}
$elasticsearch.version = "7.4.2"
$elasticsearch.download_url = "https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-{0}-windows-x86_64.zip" -f $elasticsearch.version
$elasticsearch.filename = "elasticsearch-{0}.zip" -f $elasticsearch.version
$elasticsearch.foldername = "elasticsearch-{0}" -f $elasticsearch.version


# Transform syslog output and pipe into ES
$logstash = @{}
$logstash.version = "7.4.2"
$logstash.download_url = "https://artifacts.elastic.co/downloads/logstash/logstash-{0}.zip" -f $logstash.version
$logstash.filename = "logstash-{0}.zip" -f $logstash.version
$logstash.foldername = "logstash-{0}" -f $logstash.version

# Front-end we use to query ES and display data
$kibana = @{}
$kibana.version = "7.4.2"
$kibana.download_url = "https://artifacts.elastic.co/downloads/kibana/kibana-{0}-windows-x86_64.zip" -f $kibana.version
$kibana.filename = "kibana-{0}.zip" -f $kibana.version
$kibana.foldername = "kibana-{0}-windows-x86_64" -f $kibana.version


# Allows cleanup of ES data
$curator = @{}
$curator.version = "5.8.1"
$curator.download_url = "https://packages.elastic.co/curator/5/windows/elasticsearch-curator-{0}-amd64.zip" -f $curator.version
$curator.filename = "elasticsearch-curator-{0}-amd64.zip" -f $curator.version
$curator.foldername = "curator-{0}-amd64" -f $curator.version


# Service manager
$nssm = @{}
$nssm.version = "2.24"
$nssm.download_url = "https://nssm.cc/release/nssm-{0}.zip" -f $nssm.version
$nssm.filename = "nssm-{0}.zip" -f $nssm.version
$nssm.foldername = "nssm-{0}" -f $nssm.version


$components = @{
  "elasticsearch" = $elasticsearch;
  "logstash" = $logstash;
  "kibana" = $kibana;
  "curator" = $curator;
  "nssm" = $nssm
}

# Configure where we want all the files to live
$basefolder="C:\fd-analysis"

# Folders
$elasticsearch_folder = Join-Path -Path $basefolder -ChildPath $components['elasticsearch'].foldername
$kibana_folder = Join-Path -Path $basefolder -ChildPath $components['kibana'].foldername
$nssm_folder = Join-Path -Path $basefolder -ChildPath $components['nssm'].foldername
$logstash_folder = Join-Path -Path $basefolder -ChildPath $components['logstash'].foldername
$curator_folder = Join-Path -Path $basefolder -ChildPath $components['curator'].foldername

# Scheduled task name
$curator_job = "ES_Cleanup"

# Path to in-built JDK
$jdk_path = Join-Path -Path $elasticsearch_folder -ChildPath "jdk"